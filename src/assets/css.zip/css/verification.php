<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>iParhai</title>
<link href="new-style.css" rel="stylesheet" type="text/css">
<style>
	body{		
		background: url("vf-bg.svg");
		background-size: 100%;
		background-attachment: scroll;
		background-position: top;
		background-repeat: no-repeat;
		margin: 0;
		font-family:  'Open Sans', sans-serif;
		padding: 0;
		transition-duration: 0.3s;
	}	
	.lr-heading{
		text-align: center;
		color: #161A1D ;
	}
	
	.lr-text{
		text-align: center;
	}
	
	.gender-label{
		width: 10%;
	}
	
	input[type='radio']{
		margin-left: 10%;
	}
	
	.formControl-input-code{
		width:5%;
		text-align: center;
		font-size: 2vw;
		padding: 1vw;
		margin-left: 1vw;
		float: left;
	}
	
	.formControl-btn{
		float: left;
		border-radius: 5vw;
		padding: 0.75vw 3vw;
		border: none;
		margin: auto;
		margin: 0 11.5vw;
		margin-bottom: 2vw;
		cursor: pointer;
		line-height: 2vw;
		font-size: 1.2vw;
		transition-duration: 0.3s;
	}
	
	.seperator-center{
		margin-left: 1vw;
		float: left;
		width: 6vw;
		height: 1vw;
	}
	
	.fg-pwd{
		float: left;
		margin-left: 3vw;
	}
	
	.fg-pwds{
		float: left;
		line-height: 2vw;
		color: #606060 ;
		margin-left: 22.3vw;
		font-size: 1vw;
		text-transform: uppercase;
		text-decoration: none;
		transition-duration: 0.3s;
	}

	.fg-pwds:hover{
		text-decoration: underline;
		transition-duration: 0.3s;
	}
</style>
</head>

<body marginheight="0">	
	<div class="wrapForm-vf">	
		<a href="#"><h1 class="lr-heading"><i class="i-svg-logo-bl"></i></h1></a>
		<h1 class="lr-heading"> &nbsp;Email Verification</h1>
		<span class="lr-text">We have sent you a verification code to your email address, to verify your identity.</span>
		<form>
			<span class="seperator-center"></span>
			
			<input type="text" id="input1" class="formControl-input-code formControl-input" placeholder="0" maxlength="1">
			
			<input type="text" id="input2" class=" formControl-input-code formControl-input" placeholder="1" maxlength="1">
			
			<input type="text" id="input3" class=" formControl-input-code formControl-input" placeholder="2" maxlength="1">
			
			<input type="text" id="input4" class=" formControl-input-code formControl-input" placeholder="3" maxlength="1">
			
			<input type="text" id="input5" class=" formControl-input-code formControl-input" placeholder="4" maxlength="1">
			
			<input type="text" id="input6" class=" formControl-input-code formControl-input" placeholder="5" maxlength="1">
		
			<input type="text" name="code" id="inputs" style="display: none" hidden="" class=" formControl-input formControl-input" placeholder="0123455">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script>
				$(document).ready(function(){
					$("#input1,#input2,#input3,#input4,#input5,#input6").on('keyup',function(){
						var a = $("#input1").val()+$("#input2").val()+$("#input3").val()+$("#input4").val()+$("#input5").val()+$("#input6").val();
						
						$("#inputs").val(a);
					});
					$("#input1,#input2,#input3,#input4,#input5,#input6").on('keydown',function(){
						var a = $("#input1").val()+$("#input2").val()+$("#input3").val()+$("#input4").val()+$("#input5").val()+$("#input6").val();
						
						$("#inputs").val(a);
					});
					$("#input1,#input2,#input3,#input4,#input5,#input6").on('change',function(){
						var a = $("#input1").val()+$("#input2").val()+$("#input3").val()+$("#input4").val()+$("#input5").val()+$("#input6").val();
						
						$("#inputs").val(a);
					});
					$("#input1,#input2,#input3,#input4,#input5,#input6").on('click',function(){
						var a = $("#input1").val()+$("#input2").val()+$("#input3").val()+$("#input4").val()+$("#input5").val()+$("#input6").val();
						
						$("#inputs").val(a);
					});
				});
			</script>
			
			<span class="seperator"></span>
			
			<a href="<?php echo $path; ?>Verify/Resend" class="fg-pwd">Resend The Code?</a>
			
			<a href="<?php echo $path; ?>Profile/" style="float: right; margin-right: 7vw;" class="fg-pwd">Change Email</a>
			
			<span class="seperator"></span>
			
			<span class="seperator-center"></span>
			
			<button class="lr-form-btn formControl-btn" type="submit">Verify Now</button>
			
			<a href="<?php echo $path; ?>Logout/" class="fg-pwds">Logout</a>
		</form>
	</div>
</body>
</html>